## deploy to rpi3
`SSH_KEY_FILE_PEM=~/.ssh/id_rsa  TARGET_SERVER=192.168.1.94 PORT=22 sh .temp/deploy.sh`
`SSH_KEY_FILE_PEM=~/.ssh/id_rsa  TARGET_SERVER=demo.tuanquynet.click PORT=2294 sh .temp/deploy.sh`